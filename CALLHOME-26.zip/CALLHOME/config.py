# Mail settings
mailserver = 'smtp.gmail.com'
smtpport = 587
mailusername = 'dacostapiecealerts@gmail.com'
mailpassword = 'bknd izkv zbhr jogq'
source_mailaddress = 'dacostapiecealerts@gmail.com'
dest_mailaddress = 'dacostapiecealerts@gmail.com'
mailsubject_success = "MY RASP TUN IP SERVICE ADDRESS IS: "
mailsubject_failed = "VPN Failed"

# Remote VPN Target
vpn_probe_target = "10.0.2.1"

#API Settings
api_token = "2a93dea3212543298c99b5216b0e5e12"
page_id = "qb7hs0ds4l0d"
# name = "VPN com falha"
# status = "investigating"
# impact = "major"
# # monitoring_at = f"Falha registrada em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
# body = "VPN com falha, investigando"
# name_2 = "VPN restabelecida"
# status_2 = "completed"
# # updated_at = f"Falha resolvida em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
# body_2 = "VPN restabelecida"

