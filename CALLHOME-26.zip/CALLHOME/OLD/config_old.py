# Mail settings
mailserver = 'isp07.netstructure.com.br'
smtpport = 587
mailusername = 'soc@snsec.com.br'
mailpassword = 'Alter@2024/*'
source_mailaddress = 'soc@snsec.com.br'
dest_mailaddress = 'infraestrutura@netstructure.com.br'
mailsubject_success = "MY RASP TUN IP SERVICE ADDRESS IS: "
mailsubject_failed = "VPN Failed"
