import requests
from datetime import datetime
import json

def read_incident_id_from_file(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
        return data["id"]

def update_incident(api_token, page_id, incident_id, name, status, updated_at, body):
    url = f"https://api.statuspage.io/v1/pages/{page_id}/incidents/{incident_id}"
    headers = {
        "Authorization": api_token
    }
    data = {
        "incident[name]": name,
        "incident[status]": status,
        "incident[updated_at]": updated_at,
        "incident[body]": body
    }
    response = requests.patch(url, headers=headers, data=data)
    return response

# Example usage
api_token = "2a93dea3212543298c99b5216b0e5e12"
page_id = "qb7hs0ds4l0d"
name = "VPN restabelecida"
status = "resolved"
updated_at = f"Falha resolvida em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
body = "VPN restabelecida"

# Read incident ID from file
incident_id = read_incident_id_from_file("create_incident_response.txt")

# Update incident
response = update_incident(api_token, page_id, incident_id, name, status, updated_at, body)

# Save response to a file
with open("update_incident.txt", "w") as file:
    file.write(response.text)

print("Incident updated. Response saved to update_incident.txt")
